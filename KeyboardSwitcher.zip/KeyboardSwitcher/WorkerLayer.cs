﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Gma.UserActivityMonitor;

namespace KeyboardSwitcher
{
    public partial class WorkerLayer
    {
        public void EnableGlobalHotKey()
        {
            HookManager.KeyDown += HookManager_KeyDown;
            HookManager.KeyUp += HookManager_KeyUp;
        }

        public void DisableGlobalHotKey()
        {
            HookManager.KeyDown -= HookManager_KeyDown;
            HookManager.KeyUp -= HookManager_KeyUp;
        }

        public delegate void AppendTextEventHandler(string text);

        public event AppendTextEventHandler AppendTextEvent;

        public void AddLog(string text)
        {
            if (AppendTextEvent != null)
                AppendTextEvent.Invoke(text + "\r\n");
        }

        private bool isHotkey = false;
        private Dictionary<Keys, bool> keyMap = new Dictionary<Keys, bool>();
        private int countKeyPressed = 0;
        private Keys hotKey = Keys.LShiftKey;

        private uint threadId;
        private IntPtr hWnd;
        private Switcher.Language layout;
        private string pName;

        private bool isSelectedText = false;
        private Thread threadSwitcher = null;

        private void HookManager_KeyDown(object sender, KeyEventArgs e)
        {
            isHotkey = e.KeyCode == hotKey && countKeyPressed == 0;
            bool isAddCnt = false;
            if (!keyMap.ContainsKey(e.KeyCode))
            {
                isAddCnt = true;
                keyMap.Add(e.KeyCode,true);
            }
            else
            {
                isAddCnt = !keyMap[e.KeyCode];
                keyMap[e.KeyCode] = true;
            }
            if (isAddCnt && ++countKeyPressed > 5) countKeyPressed = 5;
        }

        private void HookManager_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == hotKey && isHotkey && (threadSwitcher == null || !threadSwitcher.IsAlive))
            {
                threadSwitcher = new Thread(RunSwitcher);
                threadSwitcher.IsBackground = true;
                threadSwitcher.SetApartmentState(ApartmentState.STA);
                threadSwitcher.Start();
            }
            isHotkey = false;
            if (keyMap.ContainsKey(e.KeyCode) && keyMap[e.KeyCode])
            {
                if (--countKeyPressed < 0) countKeyPressed = 0;
                keyMap[e.KeyCode] = false;
            }
        }

        private void RunSwitcher()
        {
            Switcher.GetProcessInfo(out threadId, out hWnd, out layout, out pName);
            isSelectedText = Switcher.ReplaceSelection(threadId, layout, pName=="devenv");
            Switcher.SwitchingLayout(hWnd, layout);
        }
    }
}
