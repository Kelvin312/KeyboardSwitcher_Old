﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace KeyboardSwitcher
{
    public static class Switcher
    {
        public enum Language
        {
            enUS = 0x0409, //en-US
            ruRU = 0x0419 //ru-RU
        }

        private static bool DevenvFix(string text) //Фикс студии, когда при копировании без выделения копируется вся строка 
        {
            return (text.Length > 5 && text.StartsWith(@"   ") && text.EndsWith(@"
"));
        }

        private static IDictionary<string, object> GetClipboardData() //Копирование буфера обмена 
        {
            var dict = new Dictionary<string, object>();
            var dataObject = Clipboard.GetDataObject();
            if (dataObject != null)
                foreach (var format in dataObject.GetFormats())
                {
                    dict.Add(format, dataObject.GetData(format));
                }
            return dict;
        }

        private static void SetClipboardData(IDictionary<string, object> dict) //Восстановление буфера обмена 
        {
            DataObject dataObject = new DataObject();
            foreach (var kvp in dict)
            {
                dataObject.SetData(kvp.Key, kvp.Value);
            }
            Clipboard.SetDataObject(dataObject, true);
        }

        private static string ConvertText(string text, Language layout) //Перекодирование текста 
        {
            const string RusKey =
                "Ё!\"№;%:?*()_+ЙЦУКЕНГШЩЗХЪ/ФЫВАПРОЛДЖЭЯЧСМИТЬБЮ,ё1234567890-=йцукенгшщзхъ\\фывапролджэячсмитьбю. ";
            const string EngKey =
                "~!@#$%^&*()_+QWERTYUIOP{}|ASDFGHJKL:\"ZXCVBNM<>?`1234567890-=qwertyuiop[]\\asdfghjkl;'zxcvbnm,./ ";

            string str = "";
            switch (layout)
            {
                case Language.ruRU:
                    foreach (char c in text)
                    {
                        try
                        {
                            str += EngKey.Substring(RusKey.IndexOf(c), 1);
                        }
                        catch
                        {
                            str += c;
                        }
                    }
                    break;
                case Language.enUS:
                    foreach (char c in text)
                    {
                        try
                        {
                            str += RusKey.Substring(EngKey.IndexOf(c), 1);
                        }
                        catch
                        {
                            str += c;
                        }
                    }
                    break;
                default:
                    str = text;
                    break;
            }
            return str;
        }

        private static void SendHotKey(Keys[] keys) //Нажимает последовательность клавиш 
        {
            var inputs = new WinApi.INPUT[keys.Length];
            for (int i = 0; i < keys.Length; i++)
            {
                inputs[i] = WinApi.MakeKeyInput(keys[i], true);
            }
            WinApi.SendInput((uint) keys.Length, inputs, Marshal.SizeOf(typeof (WinApi.INPUT)));
            Thread.Sleep(40); //25 ms мало
            for (int i = keys.Length - 1; i >= 0; i--)
            {
                inputs[i] = WinApi.MakeKeyInput(keys[i], false);
            }
            WinApi.SendInput((uint) keys.Length, inputs, Marshal.SizeOf(typeof (WinApi.INPUT)));
        }

        private static IntPtr GetFocusedHandle(uint threadId) //Получение хендла активного контрола 
        {
            //@kurumpa http://stackoverflow.com/a/28409126
            IntPtr hWnd = IntPtr.Zero;
            IntPtr focusedHandle = IntPtr.Zero;
            var info = new WinApi.GUITHREADINFO();
            info.cbSize = Marshal.SizeOf(info);
            var success = WinApi.GetGUIThreadInfo(threadId, ref info);

            // target = hwndCaret || hwndFocus || (AttachThreadInput + GetFocus) || hwndActive
            var currentThreadId = WinApi.GetCurrentThreadId();
            if (currentThreadId != threadId)
            {
                WinApi.AttachThreadInput(threadId, currentThreadId, true);
                focusedHandle = WinApi.GetFocus();
                WinApi.AttachThreadInput(threadId, currentThreadId, false);
            }
            if (success)
            {
                if (info.hwndCaret != IntPtr.Zero)
                {
                    hWnd = info.hwndCaret;
                }
                else if (info.hwndFocus != IntPtr.Zero)
                {
                    hWnd = info.hwndFocus;
                }
                else if (focusedHandle != IntPtr.Zero)
                {
                    hWnd = focusedHandle;
                }
                else if (info.hwndActive != IntPtr.Zero)
                {
                    hWnd = info.hwndActive;
                }
                return hWnd;
            }
            return focusedHandle;
        }

        public static void SwitchingLayout(IntPtr hWnd, Language layout) //Смена раскладки 
        {
            switch (layout)
            {
                case Language.ruRU:
                    layout = Language.enUS;
                    break;
                case Language.enUS:
                    layout = Language.ruRU;
                    break;
                default:
                    layout = Language.enUS;
                    break;
            }
            WinApi.PostMessage(hWnd, WinApi.WM_INPUTLANGCHANGEREQUEST, IntPtr.Zero,
                WinApi.LoadKeyboardLayout(string.Format("{0:X8}", (int)layout), WinApi.KLF_ACTIVATE));
        }

        public static bool ReplaceSelection(uint threadId, Language layout, bool isAltMethod=false) //Замена выделенного текста 
        {
            bool success = false;
            if (layout != Language.enUS && layout != Language.ruRU) return success;
            IntPtr hControl = IntPtr.Zero;
            if (!isAltMethod) 
            {
                hControl = GetFocusedHandle(threadId);
                if (hControl == IntPtr.Zero) return success;
            }
            var backup = GetClipboardData();
            Clipboard.Clear();

            if (isAltMethod) SendHotKey(new Keys[] {Keys.ControlKey, Keys.C});
            else WinApi.SendMessage(hControl, WinApi.WM_COPY, IntPtr.Zero, IntPtr.Zero);
            var text = Clipboard.GetText();
            if (!(string.IsNullOrWhiteSpace(text) || isAltMethod && DevenvFix(text)))
            {
                Clipboard.SetText(ConvertText(text, layout));
                if (isAltMethod) SendHotKey(new Keys[] {Keys.ControlKey, Keys.V});
                else WinApi.SendMessage(hControl, WinApi.WM_PASTE, IntPtr.Zero, IntPtr.Zero);
                success = true;
            }

            SetClipboardData(backup); 
            return success;
        }

        public static void GetProcessInfo(out uint threadId, out IntPtr hWnd, out Language layout, out string pName) //Получение информации о процессе 
        {
            uint processId;
            hWnd = WinApi.GetForegroundWindow();
            threadId = WinApi.GetWindowThreadProcessId(hWnd, out processId);
            using (var p = Process.GetProcessById((int) processId))
            {
                pName = p.ProcessName;
            }
            layout = (Language) WinApi.LOWORD((int) WinApi.GetKeyboardLayout(threadId));
        } 
    }
}

