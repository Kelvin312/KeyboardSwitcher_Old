﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace KeyboardSwitcher
{
    public static class WinApi
    {
        #region Windows constants

        public const int WM_CUT = 0x0300;
        public const int WM_COPY = 0x0301;
        public const int WM_PASTE = 0x0302;
        public const uint WM_INPUTLANGCHANGEREQUEST = 0x0050;

        public const uint KLF_ACTIVATE = 1;
        public const int HLK_NEXT = 1; //для переключения на следующий язык
        public const int HLK_PREV = 0; //для переключения на предыдущий язык

        public const uint MAPVK_VK_TO_VSC = 0x00;
        // (The event is a keyboard event. Use the ki structure of the union.)
        public const uint INPUT_KEYBOARD = 0x01;
        // (If specified, the scan code was preceded by a prefix byte that has the value 0xE0 (224).)
        public const uint KEYEVENTF_EXTENDEDKEY = 0x0001;
        // (If specified, the key is being released. If not specified, the key is being pressed.)
        public const uint KEYEVENTF_KEYUP = 0x0002; 
        // (If specified, wScan identifies the key and wVk is ignored.)
        public const uint KEYEVENTF_UNICODE = 0x0004;
        // (Windows 2000/XP: If specified, the system synthesizes a VK_PACKET keystroke. The wVk parameter must be zero. This flag can only be combined with the KEYEVENTF_KEYUP flag. For more information, see the Remarks section.)
        public const uint KEYEVENTF_SCANCODE = 0x0008;


        #endregion Windows constants

        #region Windows structures

        public struct GUITHREADINFO
        {
            public int cbSize;
            public int flags;
            public IntPtr hwndActive;
            public IntPtr hwndFocus;
            public IntPtr hwndCapture;
            public IntPtr hwndMenuOwner;
            public IntPtr hwndMoveSize;
            public IntPtr hwndCaret;
            public System.Drawing.Rectangle rcCaret;
        }

        [StructLayout(LayoutKind.Explicit, Pack = 1)]
        public struct INPUT
        {
            [FieldOffset(0)]
            public uint type;
            [FieldOffset(4)]
            public KEYBOARD_INPUT ki;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct KEYBOARD_INPUT
        {
            public ushort wVk;
            public ushort wSc;
            public uint Flags;
            public uint Time;
            public uint dwExtraInfo;
            public uint Padding1;
            public uint Padding2;
        }

        #endregion Windows structures

        public static uint IsExtendedKey(Keys vkCode)
        {
            return 
                vkCode == Keys.Menu ||
                vkCode == Keys.LMenu ||
                vkCode == Keys.RMenu ||
                vkCode == Keys.ControlKey ||
                vkCode == Keys.LControlKey ||
                vkCode == Keys.RControlKey ||
                vkCode == Keys.Insert ||
                vkCode == Keys.Delete ||
                vkCode == Keys.Home ||
                vkCode == Keys.End ||
                vkCode == Keys.Prior ||
                vkCode == Keys.Next ||
                vkCode == Keys.Right ||
                vkCode == Keys.Up ||
                vkCode == Keys.Left ||
                vkCode == Keys.Down ||
                vkCode == Keys.NumLock ||
                vkCode == Keys.Cancel ||
                vkCode == Keys.Snapshot ||
                vkCode == Keys.Divide 
                    ? KEYEVENTF_EXTENDEDKEY
                    : 0;
        }

        public static INPUT MakeKeyInput(Keys vkCode, bool isDown, bool useScanCode=true)
        {
            return new INPUT
            {
                type = INPUT_KEYBOARD,
                ki = useScanCode ? new KEYBOARD_INPUT
                {
                    wVk = 0,
                    wSc = (ushort)MapVirtualKey((uint)vkCode, MAPVK_VK_TO_VSC),
                    Flags = KEYEVENTF_SCANCODE | (isDown ? 0 : KEYEVENTF_KEYUP),
                    Time = 0,
                    dwExtraInfo = 0
                }
                : new KEYBOARD_INPUT
                {
                    wVk = (ushort)vkCode,
                    wSc = 0,
                    Flags = IsExtendedKey(vkCode) | (isDown ? 0 : KEYEVENTF_KEYUP),
                    Time = 0,
                    dwExtraInfo = 0
                }
            };
        }

        public static int LOWORD(int dword)
        {
            return dword & 0xFFFF;
        }

        #region Windows function imports

        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool PostMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [DllImport("kernel32.dll")]
        public static extern uint GetCurrentThreadId();

        [DllImport("user32.dll")]
        public static extern IntPtr GetFocus();

        [DllImport("user32.dll")]
        public static extern IntPtr GetActiveWindow();

        [DllImport("user32.dll", SetLastError = true)]
        public static extern UInt32 SendInput(UInt32 numberOfInputs, [MarshalAs(UnmanagedType.LPArray, SizeConst = 1)] INPUT[] inputs, Int32 sizeOfInputStructure);

        [DllImport("user32.dll")]
        public static extern IntPtr GetKeyboardLayout(uint idThread);

        [DllImport("user32.dll")]
        public static extern IntPtr LoadKeyboardLayout(string pwszKLID, uint Flags);

        [DllImport("user32.dll")]
        public static extern bool GetGUIThreadInfo(uint idThread, ref GUITHREADINFO lpgui);

        [DllImport("user32.dll")]
        public static extern uint MapVirtualKey(uint uCode, uint uMapType);

        #endregion Windows function imports
    }
}
